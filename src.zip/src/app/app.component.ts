import { Component } from '@angular/core';
import { RouterOutlet, RouterLink, RouterLinkActive } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, RouterLink, RouterLinkActive],
  template: `
    <nav style="background: #2c3e50; padding: 15px; color: white; box-shadow: 0 2px 5px rgba(0,0,0,0.1)">
      <div style="max-width: 1200px; margin: 0 auto; display: flex; justify-content: space-between; align-items: center">
        <a routerLink="/home" style="color: white; text-decoration: none; font-size: 1.5rem; font-weight: bold">
          📦 InventoryHub
        </a>
        <div>
          <a routerLink="/home" routerLinkActive="active" style="color: white; margin: 0 15px; text-decoration: none">🏠 Home</a>
          <a routerLink="/inventory" routerLinkActive="active" style="color: white; margin: 0 15px; text-decoration: none">📋 Inventory</a>
          <a routerLink="/search" routerLinkActive="active" style="color: white; margin: 0 15px; text-decoration: none">🔍 Search</a>
          <a routerLink="/privacy" routerLinkActive="active" style="color: white; margin: 0 15px; text-decoration: none">🔒 Privacy</a>
          <a routerLink="/help" routerLinkActive="active" style="color: white; margin: 0 15px; text-decoration: none">❓ Help</a>
        </div>
      </div>
    </nav>
    <div style="max-width: 1200px; margin: 20px auto; padding: 0 20px">
      <router-outlet></router-outlet>
    </div>
    <footer style="text-align: center; padding: 20px; background: #2c3e50; color: white; margin-top: 40px">
      <p>PROG2005 Assignment 2 Part 2 - Angular Inventory Management System</p>
      <p>Author: [Your Name] | © 2026</p>
    </footer>
  `,
  styles: [`
    .active {
      font-weight: bold;
      border-bottom: 2px solid white;
      padding-bottom: 5px;
    }
    a:hover {
      opacity: 0.8;
    }
  `]
})
export class AppComponent {}