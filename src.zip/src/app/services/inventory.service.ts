import { Injectable } from '@angular/core';
import { Item } from '../models/item.model';

@Injectable({
    providedIn: 'root'
})
export class InventoryService {
    private items: Item[] = [];
    private nextId: number = 1;

    constructor() {
        this.items = [
            { id: 1, name: 'MacBook Pro', category: 'Electronics', quantity: 15, price: 1999, supplierName: 'Apple', stockStatus: 'In Stock', popularItem: 'Yes', comment: '' },
            { id: 2, name: 'Office Chair', category: 'Furniture', quantity: 5, price: 299, supplierName: 'IKEA', stockStatus: 'In Stock', popularItem: 'Yes', comment: '' },
            { id: 3, name: 'USB Cable', category: 'Electronics', quantity: 3, price: 12, supplierName: 'Anker', stockStatus: 'Low Stock', popularItem: 'No', comment: '' },
            { id: 4, name: 'Hammer', category: 'Tools', quantity: 25, price: 15, supplierName: 'Stanley', stockStatus: 'In Stock', popularItem: 'No', comment: '' },
            { id: 5, name: 'Levi Jeans', category: 'Clothing', quantity: 0, price: 89, supplierName: "Levi's", stockStatus: 'Out of Stock', popularItem: 'No', comment: '' }
        ];
        this.nextId = 6;
    }

    getAllItems(): Item[] {
        return [...this.items];
    }

    addItem(itemData: any): boolean {
        const stockStatus = itemData.quantity <= 0 ? 'Out of Stock' : (itemData.quantity < 10 ? 'Low Stock' : 'In Stock');
        const newItem: Item = {
            id: this.nextId++,
            name: itemData.name,
            category: itemData.category,
            quantity: itemData.quantity,
            price: itemData.price,
            supplierName: itemData.supplierName,
            stockStatus: stockStatus,
            popularItem: itemData.popularItem || 'No',
            comment: itemData.comment || ''
        };
        this.items.push(newItem);
        return true;
    }

    updateItem(id: number, data: any): boolean {
        const index = this.items.findIndex(i => i.id === id);
        if (index !== -1) {
            this.items[index].quantity = data.quantity;
            this.items[index].price = data.price;
            this.items[index].supplierName = data.supplierName;
            this.items[index].popularItem = data.popularItem;
            this.items[index].stockStatus = data.quantity <= 0 ? 'Out of Stock' : (data.quantity < 10 ? 'Low Stock' : 'In Stock');
            return true;
        }
        return false;
    }

    deleteItem(id: number): boolean {
        const index = this.items.findIndex(i => i.id === id);
        if (index !== -1) {
            this.items.splice(index, 1);
            return true;
        }
        return false;
    }
}