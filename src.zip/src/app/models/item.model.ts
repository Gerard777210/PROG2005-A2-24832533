export interface Item {
    id: number;
    name: string;
    category: string;
    quantity: number;
    price: number;
    supplierName: string;
    stockStatus: string;
    popularItem: string;
    comment?: string;
}