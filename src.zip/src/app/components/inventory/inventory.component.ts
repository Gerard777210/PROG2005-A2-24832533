﻿import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { InventoryService } from '../../services/inventory.service';
import { Item } from '../../models/item.model';

@Component({
    selector: 'app-inventory',
    standalone: true,
    imports: [CommonModule, FormsModule],
    template: `
        <h2>Inventory Management</h2>
        
        <div style="border:1px solid #ccc; padding:15px; margin:15px 0">
            <h3>Add New Item</h3>
            <input [(ngModel)]="newItem.name" placeholder="Name" style="margin:5px">
            <input [(ngModel)]="newItem.category" placeholder="Category" style="margin:5px">
            <input type="number" [(ngModel)]="newItem.quantity" placeholder="Quantity" style="margin:5px">
            <input type="number" [(ngModel)]="newItem.price" placeholder="Price" style="margin:5px">
            <input [(ngModel)]="newItem.supplierName" placeholder="Supplier" style="margin:5px">
            <button (click)="addItem()" style="margin:5px">Add Item</button>
        </div>
        
        <div style="border:1px solid #ccc; padding:15px">
            <h3>Item List</h3>
            <table style="width:100%; border-collapse:collapse">
                <thead>
                    <tr style="background:#f0f0f0">
                        <th style="border:1px solid #ddd; padding:8px">ID</th>
                        <th style="border:1px solid #ddd; padding:8px">Name</th>
                        <th style="border:1px solid #ddd; padding:8px">Category</th>
                        <th style="border:1px solid #ddd; padding:8px">Quantity</th>
                        <th style="border:1px solid #ddd; padding:8px">Price</th>
                        <th style="border:1px solid #ddd; padding:8px">Supplier</th>
                        <th style="border:1px solid #ddd; padding:8px">Status</th>
                        <th style="border:1px solid #ddd; padding:8px">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr *ngFor="let item of items">
                        <td style="border:1px solid #ddd; padding:8px">{{item.id}}</td>
                        <td style="border:1px solid #ddd; padding:8px">{{item.name}}</td>
                        <td style="border:1px solid #ddd; padding:8px">{{item.category}}</td>
                        <td style="border:1px solid #ddd; padding:8px">{{item.quantity}}</td>
                        <td style="border:1px solid #ddd; padding:8px">\${{item.price}}</td>
                        <td style="border:1px solid #ddd; padding:8px">{{item.supplierName}}</td>
                        <td style="border:1px solid #ddd; padding:8px">
                            <span [style.color]="item.stockStatus === 'Low Stock' ? 'orange' : (item.stockStatus === 'Out of Stock' ? 'red' : 'green')">
                                {{item.stockStatus}}
                            </span>
                        </td>
                        <td style="border:1px solid #ddd; padding:8px">
                            <button (click)="deleteItem(item.id)">Delete</button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    `
})
export class InventoryComponent implements OnInit {
    items: Item[] = [];
    newItem = { name: '', category: '', quantity: 0, price: 0, supplierName: '' };

    constructor(private inventoryService: InventoryService) {}

    ngOnInit() {
        this.items = this.inventoryService.getAllItems();
    }

    addItem() {
        if (this.newItem.name && this.newItem.category && this.newItem.supplierName) {
            this.inventoryService.addItem(this.newItem);
            this.items = this.inventoryService.getAllItems();
            this.newItem = { name: '', category: '', quantity: 0, price: 0, supplierName: '' };
        }
    }

    deleteItem(id: number) {
        if (confirm('Delete this item?')) {
            this.inventoryService.deleteItem(id);
            this.items = this.inventoryService.getAllItems();
        }
    }
}