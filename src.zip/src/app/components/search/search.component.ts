﻿import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { InventoryService } from '../../services/inventory.service';
import { Item } from '../../models/item.model';

@Component({
    selector: 'app-search',
    standalone: true,
    imports: [CommonModule, FormsModule],
    template: `
        <h2>🔍 Search Inventory</h2>

        <div style="background: #f8f9fa; padding: 20px; border-radius: 10px; margin: 20px 0">
            <div style="display: flex; gap: 10px; flex-wrap: wrap">
                <input type="text" [(ngModel)]="searchTerm" placeholder="Search by name..." 
                       style="flex:1; padding:10px; border:1px solid #ddd; border-radius:5px">
                <button (click)="search()" style="padding:10px 20px; background:#007bff; color:white; border:none; border-radius:5px">Search</button>
                <button (click)="showAll()" style="padding:10px 20px; background:#6c757d; color:white; border:none; border-radius:5px">Show All</button>
                <button (click)="showPopular()" style="padding:10px 20px; background:#ffc107; color:#333; border:none; border-radius:5px">Popular Items</button>
            </div>
        </div>

        <div style="background: white; padding: 20px; border-radius: 10px; box-shadow: 0 2px 5px rgba(0,0,0,0.1)">
            <h3>{{title}}</h3>
            <table style="width:100%; border-collapse:collapse">
                <thead>
                    <tr style="background:#f0f0f0">
                        <th style="border:1px solid #ddd; padding:10px">ID</th>
                        <th style="border:1px solid #ddd; padding:10px">Name</th>
                        <th style="border:1px solid #ddd; padding:10px">Category</th>
                        <th style="border:1px solid #ddd; padding:10px">Quantity</th>
                        <th style="border:1px solid #ddd; padding:10px">Price</th>
                        <th style="border:1px solid #ddd; padding:10px">Supplier</th>
                        <th style="border:1px solid #ddd; padding:10px">Status</th>
                    </tr>
                </thead>
                <tbody>
                    <tr *ngFor="let item of searchResults">
                        <td style="border:1px solid #ddd; padding:10px">{{item.id}}</td>
                        <td style="border:1px solid #ddd; padding:10px">{{item.name}}</td>
                        <td style="border:1px solid #ddd; padding:10px">{{item.category}}</td>
                        <td style="border:1px solid #ddd; padding:10px">{{item.quantity}}</td>
                        <td style="border:1px solid #ddd; padding:10px">\${{item.price}}</td>
                        <td style="border:1px solid #ddd; padding:10px">{{item.supplierName}}</td>
                        <td style="border:1px solid #ddd; padding:10px">
                            <span [style.color]="item.stockStatus === 'Low Stock' ? 'orange' : (item.stockStatus === 'Out of Stock' ? 'red' : 'green')">
                                {{item.stockStatus}}
                            </span>
                        </td>
                    </tr>
                    <tr *ngIf="searchResults.length === 0">
                        <td colspan="7" style="text-align:center; padding:40px">No items found</td>
                    </tr>
                </tbody>
            </table>
        </div>
    `
})
export class SearchComponent {
    searchTerm: string = '';
    searchResults: Item[] = [];
    title: string = 'All Items';

    constructor(private inventoryService: InventoryService) {
        this.showAll();
    }

    search() {
        if (this.searchTerm.trim()) {
            this.searchResults = this.inventoryService.getAllItems().filter(i => 
                i.name.toLowerCase().includes(this.searchTerm.toLowerCase())
            );
            this.title = `Search Results for "${this.searchTerm}"`;
        }
    }

    showAll() {
        this.searchResults = this.inventoryService.getAllItems();
        this.title = 'All Items';
        this.searchTerm = '';
    }

    showPopular() {
        this.searchResults = this.inventoryService.getAllItems().filter(i => i.popularItem === 'Yes');
        this.title = 'Popular Items';
        this.searchTerm = '';
    }
}