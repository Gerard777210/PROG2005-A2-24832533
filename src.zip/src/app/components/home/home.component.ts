import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InventoryService } from '../../services/inventory.service';

@Component({
    selector: 'app-home',
    standalone: true,
    imports: [CommonModule],
    template: `
        <div style="text-align: center; padding: 50px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 15px; color: white">
            <h1 style="font-size: 3rem">📦 InventoryHub</h1>
            <p style="font-size: 1.2rem">Enterprise Inventory Management System</p>
            <p>Harvey Norman Inventory Database - Angular Edition</p>
        </div>

        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; margin: 40px 0">
            <div style="padding: 25px; text-align: center; background: #f8f9fa; border-radius: 10px; box-shadow: 0 2px 5px rgba(0,0,0,0.1)">
                <div style="font-size: 3rem">➕</div>
                <h3>Add Items</h3>
                <p>Easily add new inventory items with all required fields</p>
            </div>
            <div style="padding: 25px; text-align: center; background: #f8f9fa; border-radius: 10px; box-shadow: 0 2px 5px rgba(0,0,0,0.1)">
                <div style="font-size: 3rem">✏️</div>
                <h3>Edit & Delete</h3>
                <p>Update existing items or remove them with confirmation</p>
            </div>
            <div style="padding: 25px; text-align: center; background: #f8f9fa; border-radius: 10px; box-shadow: 0 2px 5px rgba(0,0,0,0.1)">
                <div style="font-size: 3rem">🔍</div>
                <h3>Search & Filter</h3>
                <p>Find items by name or filter popular items</p>
            </div>
        </div>

        <div style="background: #2c3e50; color: white; padding: 30px; border-radius: 10px; text-align: center">
            <h3>📊 Inventory Statistics</h3>
            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-top: 20px">
                <div>
                    <div style="font-size: 2rem; font-weight: bold">{{stats.total}}</div>
                    <div>Total Items</div>
                </div>
                <div>
                    <div style="font-size: 2rem; font-weight: bold">{{stats.popular}}</div>
                    <div>Popular Items</div>
                </div>
                <div>
                    <div style="font-size: 2rem; font-weight: bold">{{stats.lowStock}}</div>
                    <div>Low Stock</div>
                </div>
                <div>
                    <div style="font-size: 2rem; font-weight: bold">{{stats.outOfStock}}</div>
                    <div>Out of Stock</div>
                </div>
            </div>
        </div>
    `
})
export class HomeComponent implements OnInit {
    stats = { total: 0, popular: 0, lowStock: 0, outOfStock: 0 };

    constructor(private inventoryService: InventoryService) {}

    ngOnInit() {
        const items = this.inventoryService.getAllItems();
        this.stats.total = items.length;
        this.stats.popular = items.filter(i => i.popularItem === 'Yes').length;
        this.stats.lowStock = items.filter(i => i.stockStatus === 'Low Stock').length;
        this.stats.outOfStock = items.filter(i => i.stockStatus === 'Out of Stock').length;
    }
}