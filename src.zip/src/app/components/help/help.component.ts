﻿import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
    selector: 'app-help',
    standalone: true,
    imports: [CommonModule],
    template: `
        <h2>❓ Help & FAQ</h2>
        
        <div *ngFor="let faq of faqs" style="background: #f8f9fa; padding: 15px; border-radius: 10px; margin: 15px 0">
            <h3 (click)="faq.open = !faq.open" style="cursor: pointer; color: #007bff">
                {{faq.open ? '▼' : '▶'}} {{faq.question}}
            </h3>
            <div *ngIf="faq.open" style="padding-left: 20px; color: #555">
                <p>{{faq.answer}}</p>
            </div>
        </div>
        
        <div style="background: #e3f2fd; padding: 20px; border-radius: 10px; margin: 20px 0; text-align: center">
            <h3>📞 Still Need Help?</h3>
            <p>Contact our support team: <a href="mailto:support@inventoryhub.com">support@inventoryhub.com</a></p>
        </div>
    `
})
export class HelpComponent {
    faqs = [
        { question: 'How do I add a new item?', answer: 'Go to Inventory page, fill out the form with item details (Name, Category, Quantity, Price, Supplier), then click "Add Item".', open: true },
        { question: 'How do I delete an item?', answer: 'Click the "Delete" button next to any item in the inventory list. You will be prompted to confirm before deletion.', open: false },
        { question: 'How do I search for items?', answer: 'Go to Search page, enter an item name and click "Search". You can also use "Show All" or "Popular Items" buttons.', open: false },
        { question: 'What do the stock status colors mean?', answer: 'Green = In Stock (10+ units), Orange = Low Stock (1-9 units), Red = Out of Stock (0 units).', open: false },
        { question: 'Is my data saved after closing the browser?', answer: 'Currently, data is stored in memory during your session. For production, we recommend using a backend database.', open: false }
    ];
}