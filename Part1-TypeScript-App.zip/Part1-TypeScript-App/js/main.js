// ts/main.ts
// Author: [Your Name]
// Assignment: PROG2005 A2 Part 1
// Description: Main application logic for inventory management system
// Version: 2.0 - Enterprise Edition
import { InventoryService } from './services/InventoryService.js';
import { Item } from './models/Item.js';
class InventoryApp {
    constructor() {
        this.inventoryService = new InventoryService();
        this.currentDisplayElement = document.getElementById('inventory-display');
        this.initializeEventListeners();
        this.displayAllItems();
        this.updateNavStats();
    }
    initializeEventListeners() {
        // Add Item Form
        const addForm = document.getElementById('add-item-form');
        if (addForm) {
            addForm.addEventListener('submit', (e) => this.handleAddItem(e));
        }
        // Update Item Form
        const updateForm = document.getElementById('update-item-form');
        if (updateForm) {
            updateForm.addEventListener('submit', (e) => this.handleUpdateItem(e));
        }
        // Delete Item Button
        const deleteBtn = document.getElementById('delete-item-btn');
        if (deleteBtn) {
            deleteBtn.addEventListener('click', () => this.handleDeleteItem());
        }
        // Search Button
        const searchBtn = document.getElementById('search-btn');
        if (searchBtn) {
            searchBtn.addEventListener('click', () => this.handleSearch());
        }
        // Show All Button
        const showAllBtn = document.getElementById('show-all-btn');
        if (showAllBtn) {
            showAllBtn.addEventListener('click', () => this.displayAllItems());
        }
        // Show Popular Button
        const showPopularBtn = document.getElementById('show-popular-btn');
        if (showPopularBtn) {
            showPopularBtn.addEventListener('click', () => this.displayPopularItems());
        }
        // Enter key on search
        const searchInput = document.getElementById('search-input');
        if (searchInput) {
            searchInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter')
                    this.handleSearch();
            });
        }
        // Update search name field
        const updateSearchName = document.getElementById('update-search-name');
        if (updateSearchName) {
            updateSearchName.addEventListener('input', () => this.checkItemForUpdate());
        }
    }
    checkItemForUpdate() {
        const searchNameInput = document.getElementById('update-search-name');
        const searchName = searchNameInput.value.trim();
        if (!searchName) {
            const updateSection = document.getElementById('update-fields-section');
            if (updateSection)
                updateSection.style.display = 'none';
            return;
        }
        const existingItem = this.inventoryService.getItemByName(searchName);
        if (existingItem) {
            this.populateUpdateForm(existingItem);
            const updateSection = document.getElementById('update-fields-section');
            if (updateSection)
                updateSection.style.display = 'block';
        }
        else {
            const updateSection = document.getElementById('update-fields-section');
            if (updateSection)
                updateSection.style.display = 'none';
            this.showMessage(`Item "${searchName}" not found!`, 'error');
        }
    }
    populateUpdateForm(item) {
        const nameInput = document.getElementById('update-name');
        const categorySelect = document.getElementById('update-category');
        const quantityInput = document.getElementById('update-quantity');
        const priceInput = document.getElementById('update-price');
        const supplierInput = document.getElementById('update-supplier');
        const popularSelect = document.getElementById('update-popular');
        const commentInput = document.getElementById('update-comment');
        if (nameInput)
            nameInput.value = item.name;
        if (categorySelect)
            categorySelect.value = item.category;
        if (quantityInput)
            quantityInput.value = item.quantity.toString();
        if (priceInput)
            priceInput.value = item.price.toString();
        if (supplierInput)
            supplierInput.value = item.supplierName;
        if (popularSelect)
            popularSelect.value = item.popularItem;
        if (commentInput)
            commentInput.value = item.comment || '';
        // Setup confirm button
        const confirmBtn = document.getElementById('confirm-update-btn');
        if (confirmBtn) {
            const newConfirmBtn = confirmBtn.cloneNode(true);
            confirmBtn.parentNode?.replaceChild(newConfirmBtn, confirmBtn);
            newConfirmBtn.addEventListener('click', () => this.handleConfirmUpdate(item.name));
        }
    }
    handleConfirmUpdate(originalName) {
        const nameInput = document.getElementById('update-name');
        const categorySelect = document.getElementById('update-category');
        const quantityInput = document.getElementById('update-quantity');
        const priceInput = document.getElementById('update-price');
        const supplierInput = document.getElementById('update-supplier');
        const popularSelect = document.getElementById('update-popular');
        const commentInput = document.getElementById('update-comment');
        const updatedData = {
            name: nameInput.value.trim(),
            category: categorySelect.value,
            quantity: parseInt(quantityInput.value),
            price: parseFloat(priceInput.value),
            supplierName: supplierInput.value.trim(),
            popularItem: popularSelect.value,
            comment: commentInput.value.trim() || undefined
        };
        const validation = this.inventoryService.validateItemData({
            name: updatedData.name,
            quantity: updatedData.quantity,
            price: updatedData.price,
            supplierName: updatedData.supplierName
        });
        if (!validation.isValid) {
            this.showMessage(validation.errors.join(', '), 'error');
            return;
        }
        if (this.inventoryService.updateItemByName(originalName, updatedData)) {
            this.showMessage(`Item "${originalName}" updated successfully!`, 'success');
            this.clearUpdateForm();
            const updateSection = document.getElementById('update-fields-section');
            if (updateSection)
                updateSection.style.display = 'none';
            const searchInput = document.getElementById('update-search-name');
            if (searchInput)
                searchInput.value = '';
            this.displayAllItems();
            this.updateNavStats();
        }
        else {
            this.showMessage('Failed to update item', 'error');
        }
    }
    handleAddItem(e) {
        e.preventDefault();
        const nameInput = document.getElementById('add-name');
        const categorySelect = document.getElementById('add-category');
        const quantityInput = document.getElementById('add-quantity');
        const priceInput = document.getElementById('add-price');
        const supplierInput = document.getElementById('add-supplier');
        const popularSelect = document.getElementById('add-popular');
        const commentInput = document.getElementById('add-comment');
        const name = nameInput.value.trim();
        const category = categorySelect.value;
        const quantity = parseInt(quantityInput.value);
        const price = parseFloat(priceInput.value);
        const supplier = supplierInput.value.trim();
        const popular = popularSelect.value;
        const comment = commentInput.value.trim() || undefined;
        // Validation
        const validation = this.inventoryService.validateItemData({
            name, quantity, price, supplierName: supplier
        });
        if (!validation.isValid) {
            this.showMessage(validation.errors.join(', '), 'error');
            return;
        }
        // Check if item name already exists
        if (this.inventoryService.getItemByName(name)) {
            this.showMessage(`Item "${name}" already exists!`, 'error');
            return;
        }
        const newItem = new Item(name, category, quantity, price, supplier, popular, comment);
        if (this.inventoryService.addItem(newItem)) {
            this.showMessage(`Item "${name}" added successfully!`, 'success');
            this.clearAddForm();
            this.displayAllItems();
            this.updateNavStats();
        }
        else {
            this.showMessage('Failed to add item', 'error');
        }
    }
    handleUpdateItem(e) {
        e.preventDefault();
        const searchNameInput = document.getElementById('update-search-name');
        const searchName = searchNameInput.value.trim();
        if (!searchName) {
            this.showMessage('Please enter an item name to search for update', 'error');
            return;
        }
        const existingItem = this.inventoryService.getItemByName(searchName);
        if (!existingItem) {
            this.showMessage(`Item "${searchName}" not found!`, 'error');
            return;
        }
        this.populateUpdateForm(existingItem);
        const updateSection = document.getElementById('update-fields-section');
        if (updateSection)
            updateSection.style.display = 'block';
    }
    handleDeleteItem() {
        const nameInput = document.getElementById('delete-name');
        const name = nameInput.value.trim();
        if (!name) {
            this.showMessage('Please enter an item name to delete', 'error');
            return;
        }
        const item = this.inventoryService.getItemByName(name);
        if (!item) {
            this.showMessage(`Item "${name}" not found!`, 'error');
            return;
        }
        if (confirm(`Are you sure you want to delete "${name}"? This action cannot be undone.`)) {
            if (this.inventoryService.deleteItemByName(name)) {
                this.showMessage(`Item "${name}" deleted successfully!`, 'success');
                nameInput.value = '';
                this.displayAllItems();
                this.updateNavStats();
            }
            else {
                this.showMessage('Failed to delete item', 'error');
            }
        }
    }
    handleSearch() {
        const searchInput = document.getElementById('search-input');
        const searchTerm = searchInput.value.trim();
        if (!searchTerm) {
            this.displayAllItems();
            return;
        }
        const results = this.inventoryService.searchItemsByName(searchTerm);
        this.displayItems(results, `Search Results for "${this.escapeHtml(searchTerm)}"`);
    }
    displayAllItems() {
        const items = this.inventoryService.getAllItems();
        this.displayItems(items, 'All Inventory Items');
    }
    displayPopularItems() {
        const items = this.inventoryService.getPopularItems();
        this.displayItems(items, 'Popular Items');
    }
    displayItems(items, title) {
        if (!this.currentDisplayElement)
            return;
        if (items.length === 0) {
            this.currentDisplayElement.innerHTML = `
                <div class="empty-state">
                    <div class="empty-state-icon">📦</div>
                    <p>No items to display</p>
                    <p style="font-size: 0.8rem; margin-top: 0.5rem;">Click "Add New Item" to get started</p>
                </div>
            `;
            return;
        }
        const tableHtml = `
            <table class="inventory-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Item Name</th>
                        <th>Category</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>Supplier</th>
                        <th>Stock Status</th>
                        <th>Popular</th>
                        <th>Comment</th>
                    </tr>
                </thead>
                <tbody>
                    ${items.map(item => `
                        <tr class="${item.stockStatus === 'Out of Stock' ? 'out-of-stock' : ''}">
                            <td>${item.id}</td>
                            <td><strong>${this.escapeHtml(item.name)}</strong></td>
                            <td>${this.getCategoryIcon(item.category)} ${item.category}</td>
                            <td>${item.quantity}</td>
                            <td>$${item.price.toFixed(2)}</td>
                            <td>${this.escapeHtml(item.supplierName)}</td>
                            <td><span class="status-badge status-${item.stockStatus.replace(/\s/g, '-')}">${item.stockStatus}</span></td>
                            <td>${item.popularItem === 'Yes' ? '<span class="popular-badge">⭐ Popular</span>' : 'No'}</td>
                            <td>${this.escapeHtml(item.comment || '-')}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
            <div style="padding: 1rem; text-align: right; border-top: 1px solid var(--gray-200);">
                <small style="color: var(--gray-500);">Showing ${items.length} item(s)</small>
            </div>
        `;
        this.currentDisplayElement.innerHTML = tableHtml;
    }
    getCategoryIcon(category) {
        const icons = {
            'Electronics': '📱',
            'Furniture': '🪑',
            'Clothing': '👕',
            'Tools': '🔧',
            'Miscellaneous': '📦'
        };
        return icons[category] || '📦';
    }
    updateNavStats() {
        const items = this.inventoryService.getAllItems();
        const totalItems = items.length;
        const popularItems = items.filter(i => i.popularItem === 'Yes').length;
        const lowStockItems = items.filter(i => i.stockStatus === 'Low Stock').length;
        const totalEl = document.getElementById('total-items');
        const popularEl = document.getElementById('popular-items');
        const lowStockEl = document.getElementById('low-stock');
        if (totalEl)
            totalEl.textContent = totalItems.toString();
        if (popularEl)
            popularEl.textContent = popularItems.toString();
        if (lowStockEl)
            lowStockEl.textContent = lowStockItems.toString();
    }
    showMessage(message, type) {
        const messageDiv = document.getElementById('message-area');
        if (!messageDiv)
            return;
        const alertClass = type === 'success' ? 'success' : 'error';
        messageDiv.innerHTML = `<div class="message ${alertClass}">${type === 'success' ? '✓' : '✗'} ${this.escapeHtml(message)}</div>`;
        setTimeout(() => {
            if (messageDiv.firstChild) {
                messageDiv.removeChild(messageDiv.firstChild);
            }
        }, 3000);
    }
    clearAddForm() {
        const inputs = ['add-name', 'add-quantity', 'add-price', 'add-supplier'];
        inputs.forEach(id => {
            const el = document.getElementById(id);
            if (el)
                el.value = '';
        });
        const categorySelect = document.getElementById('add-category');
        if (categorySelect)
            categorySelect.value = 'Electronics';
        const popularSelect = document.getElementById('add-popular');
        if (popularSelect)
            popularSelect.value = 'No';
        const commentArea = document.getElementById('add-comment');
        if (commentArea)
            commentArea.value = '';
    }
    clearUpdateForm() {
        const inputs = ['update-name', 'update-quantity', 'update-price', 'update-supplier'];
        inputs.forEach(id => {
            const el = document.getElementById(id);
            if (el)
                el.value = '';
        });
        const categorySelect = document.getElementById('update-category');
        if (categorySelect)
            categorySelect.value = 'Electronics';
        const popularSelect = document.getElementById('update-popular');
        if (popularSelect)
            popularSelect.value = 'No';
        const commentArea = document.getElementById('update-comment');
        if (commentArea)
            commentArea.value = '';
    }
    escapeHtml(str) {
        if (!str)
            return '';
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }
}
// Initialize the app when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    new InventoryApp();
});
//# sourceMappingURL=main.js.map