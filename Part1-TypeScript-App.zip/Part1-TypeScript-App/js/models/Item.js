// ts/models/Item.ts
// Author: [Your Name]
// Assignment: PROG2005 A2 Part 1
// Description: Inventory item data model
export class Item {
    constructor(name, category, quantity, price, supplierName, popularItem, comment) {
        this.id = Item.nextId++;
        this.name = name;
        this.category = category;
        this.quantity = quantity;
        this.price = price;
        this.supplierName = supplierName;
        this.stockStatus = this.calculateStockStatus(quantity);
        this.popularItem = popularItem;
        this.comment = comment;
    }
    calculateStockStatus(quantity) {
        if (quantity <= 0)
            return 'Out of Stock';
        if (quantity < 10)
            return 'Low Stock';
        return 'In Stock';
    }
    updateStockStatus() {
        this.stockStatus = this.calculateStockStatus(this.quantity);
    }
    updateQuantity(newQuantity) {
        this.quantity = newQuantity;
        this.updateStockStatus();
    }
}
Item.nextId = 1;
//# sourceMappingURL=Item.js.map