// ts/services/InventoryService.ts
// Author: [Your Name]
// Assignment: PROG2005 A2 Part 1
// Description: Service for managing inventory operations
import { Item } from '../models/Item.js';
export class InventoryService {
    constructor() {
        this.items = [];
        this.idSet = new Set();
        this.initializeSampleData();
    }
    initializeSampleData() {
        const sampleItems = [
            { name: 'MacBook Pro', category: 'Electronics', quantity: 15, price: 1999, supplierName: 'Apple Inc.', popularItem: 'Yes', comment: 'Latest M3 chip' },
            { name: 'Office Chair', category: 'Furniture', quantity: 5, price: 299, supplierName: 'IKEA', popularItem: 'Yes', comment: 'Ergonomic design' },
            { name: 'Levi Jeans', category: 'Clothing', quantity: 0, price: 89, supplierName: 'Levi\'s', popularItem: 'No', comment: 'Blue denim' },
            { name: 'Hammer', category: 'Tools', quantity: 25, price: 15, supplierName: 'Stanley', popularItem: 'No' },
            { name: 'USB Cable', category: 'Electronics', quantity: 3, price: 12, supplierName: 'Anker', popularItem: 'Yes' }
        ];
        sampleItems.forEach(item => {
            const newItem = new Item(item.name, item.category, item.quantity, item.price, item.supplierName, item.popularItem, item.comment);
            this.items.push(newItem);
            this.idSet.add(newItem.id);
        });
    }
    // Get all items
    getAllItems() {
        return [...this.items];
    }
    // Get item by ID
    getItemById(id) {
        return this.items.find(item => item.id === id);
    }
    // Get item by name
    getItemByName(name) {
        return this.items.find(item => item.name.toLowerCase() === name.toLowerCase());
    }
    // Add new item
    addItem(item) {
        // Check if name already exists
        if (this.getItemByName(item.name)) {
            return false;
        }
        this.items.push(item);
        this.idSet.add(item.id);
        return true;
    }
    // Update item by name
    updateItemByName(name, updatedData) {
        const item = this.getItemByName(name);
        if (!item)
            return false;
        // Update fields
        Object.assign(item, updatedData);
        // Update stock status if quantity changed
        if (updatedData.quantity !== undefined) {
            item.updateStockStatus();
        }
        return true;
    }
    // Delete item by name (with confirmation handled by UI)
    deleteItemByName(name) {
        const index = this.items.findIndex(item => item.name.toLowerCase() === name.toLowerCase());
        if (index === -1)
            return false;
        const deletedItem = this.items[index];
        this.idSet.delete(deletedItem.id);
        this.items.splice(index, 1);
        return true;
    }
    // Search items by name (partial match)
    searchItemsByName(searchTerm) {
        const term = searchTerm.toLowerCase();
        return this.items.filter(item => item.name.toLowerCase().includes(term));
    }
    // Get all popular items
    getPopularItems() {
        return this.items.filter(item => item.popularItem === 'Yes');
    }
    // Validate item data before add/update
    validateItemData(data) {
        const errors = [];
        if (data.name !== undefined) {
            if (!data.name || data.name.trim() === '') {
                errors.push('Item name cannot be empty');
            }
        }
        if (data.quantity !== undefined) {
            if (isNaN(data.quantity) || data.quantity < 0) {
                errors.push('Quantity must be a non-negative number');
            }
        }
        if (data.price !== undefined) {
            if (isNaN(data.price) || data.price <= 0) {
                errors.push('Price must be a positive number');
            }
        }
        if (data.supplierName !== undefined) {
            if (!data.supplierName || data.supplierName.trim() === '') {
                errors.push('Supplier name cannot be empty');
            }
        }
        return { isValid: errors.length === 0, errors };
    }
}
//# sourceMappingURL=InventoryService.js.map