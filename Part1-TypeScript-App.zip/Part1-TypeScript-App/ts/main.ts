// ts/main.ts
// Author: [Your Name]
// Assignment: PROG2005 A2 Part 1
// Description: Main application logic for inventory management system
// Version: 2.0 - Enterprise Edition

import { InventoryService } from './services/InventoryService.js';
import { Item, Category, PopularStatus, StockStatus } from './models/Item.js';

class InventoryApp {
    private inventoryService: InventoryService;
    private currentDisplayElement: HTMLElement;

    constructor() {
        this.inventoryService = new InventoryService();
        this.currentDisplayElement = document.getElementById('inventory-display')!;
        this.initializeEventListeners();
        this.displayAllItems();
        this.updateNavStats();
    }

    private initializeEventListeners(): void {
        // Add Item Form
        const addForm = document.getElementById('add-item-form') as HTMLFormElement;
        if (addForm) {
            addForm.addEventListener('submit', (e) => this.handleAddItem(e));
        }

        // Update Item Form
        const updateForm = document.getElementById('update-item-form');
        if (updateForm) {
            updateForm.addEventListener('submit', (e) => this.handleUpdateItem(e));
        }

        // Delete Item Button
        const deleteBtn = document.getElementById('delete-item-btn');
        if (deleteBtn) {
            deleteBtn.addEventListener('click', () => this.handleDeleteItem());
        }

        // Search Button
        const searchBtn = document.getElementById('search-btn');
        if (searchBtn) {
            searchBtn.addEventListener('click', () => this.handleSearch());
        }

        // Show All Button
        const showAllBtn = document.getElementById('show-all-btn');
        if (showAllBtn) {
            showAllBtn.addEventListener('click', () => this.displayAllItems());
        }

        // Show Popular Button
        const showPopularBtn = document.getElementById('show-popular-btn');
        if (showPopularBtn) {
            showPopularBtn.addEventListener('click', () => this.displayPopularItems());
        }

        // Enter key on search
        const searchInput = document.getElementById('search-input') as HTMLInputElement;
        if (searchInput) {
            searchInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') this.handleSearch();
            });
        }

        // Update search name field
        const updateSearchName = document.getElementById('update-search-name') as HTMLInputElement;
        if (updateSearchName) {
            updateSearchName.addEventListener('input', () => this.checkItemForUpdate());
        }
    }

    private checkItemForUpdate(): void {
        const searchNameInput = document.getElementById('update-search-name') as HTMLInputElement;
        const searchName = searchNameInput.value.trim();
        
        if (!searchName) {
            const updateSection = document.getElementById('update-fields-section');
            if (updateSection) updateSection.style.display = 'none';
            return;
        }

        const existingItem = this.inventoryService.getItemByName(searchName);
        
        if (existingItem) {
            this.populateUpdateForm(existingItem);
            const updateSection = document.getElementById('update-fields-section');
            if (updateSection) updateSection.style.display = 'block';
        } else {
            const updateSection = document.getElementById('update-fields-section');
            if (updateSection) updateSection.style.display = 'none';
            this.showMessage(`Item "${searchName}" not found!`, 'error');
        }
    }

    private populateUpdateForm(item: Item): void {
        const nameInput = document.getElementById('update-name') as HTMLInputElement;
        const categorySelect = document.getElementById('update-category') as HTMLSelectElement;
        const quantityInput = document.getElementById('update-quantity') as HTMLInputElement;
        const priceInput = document.getElementById('update-price') as HTMLInputElement;
        const supplierInput = document.getElementById('update-supplier') as HTMLInputElement;
        const popularSelect = document.getElementById('update-popular') as HTMLSelectElement;
        const commentInput = document.getElementById('update-comment') as HTMLTextAreaElement;

        if (nameInput) nameInput.value = item.name;
        if (categorySelect) categorySelect.value = item.category;
        if (quantityInput) quantityInput.value = item.quantity.toString();
        if (priceInput) priceInput.value = item.price.toString();
        if (supplierInput) supplierInput.value = item.supplierName;
        if (popularSelect) popularSelect.value = item.popularItem;
        if (commentInput) commentInput.value = item.comment || '';

        // Setup confirm button
        const confirmBtn = document.getElementById('confirm-update-btn');
        if (confirmBtn) {
            const newConfirmBtn = confirmBtn.cloneNode(true);
            confirmBtn.parentNode?.replaceChild(newConfirmBtn, confirmBtn);
            newConfirmBtn.addEventListener('click', () => this.handleConfirmUpdate(item.name));
        }
    }

    private handleConfirmUpdate(originalName: string): void {
        const nameInput = document.getElementById('update-name') as HTMLInputElement;
        const categorySelect = document.getElementById('update-category') as HTMLSelectElement;
        const quantityInput = document.getElementById('update-quantity') as HTMLInputElement;
        const priceInput = document.getElementById('update-price') as HTMLInputElement;
        const supplierInput = document.getElementById('update-supplier') as HTMLInputElement;
        const popularSelect = document.getElementById('update-popular') as HTMLSelectElement;
        const commentInput = document.getElementById('update-comment') as HTMLTextAreaElement;

        const updatedData: Partial<Item> = {
            name: nameInput.value.trim(),
            category: categorySelect.value as Category,
            quantity: parseInt(quantityInput.value),
            price: parseFloat(priceInput.value),
            supplierName: supplierInput.value.trim(),
            popularItem: popularSelect.value as PopularStatus,
            comment: commentInput.value.trim() || undefined
        };

        const validation = this.inventoryService.validateItemData({
            name: updatedData.name,
            quantity: updatedData.quantity,
            price: updatedData.price,
            supplierName: updatedData.supplierName
        });

        if (!validation.isValid) {
            this.showMessage(validation.errors.join(', '), 'error');
            return;
        }

        if (this.inventoryService.updateItemByName(originalName, updatedData)) {
            this.showMessage(`Item "${originalName}" updated successfully!`, 'success');
            this.clearUpdateForm();
            const updateSection = document.getElementById('update-fields-section');
            if (updateSection) updateSection.style.display = 'none';
            const searchInput = document.getElementById('update-search-name') as HTMLInputElement;
            if (searchInput) searchInput.value = '';
            this.displayAllItems();
            this.updateNavStats();
        } else {
            this.showMessage('Failed to update item', 'error');
        }
    }

    private handleAddItem(e: Event): void {
        e.preventDefault();
        
        const nameInput = document.getElementById('add-name') as HTMLInputElement;
        const categorySelect = document.getElementById('add-category') as HTMLSelectElement;
        const quantityInput = document.getElementById('add-quantity') as HTMLInputElement;
        const priceInput = document.getElementById('add-price') as HTMLInputElement;
        const supplierInput = document.getElementById('add-supplier') as HTMLInputElement;
        const popularSelect = document.getElementById('add-popular') as HTMLSelectElement;
        const commentInput = document.getElementById('add-comment') as HTMLTextAreaElement;

        const name = nameInput.value.trim();
        const category = categorySelect.value as Category;
        const quantity = parseInt(quantityInput.value);
        const price = parseFloat(priceInput.value);
        const supplier = supplierInput.value.trim();
        const popular = popularSelect.value as PopularStatus;
        const comment = commentInput.value.trim() || undefined;

        // Validation
        const validation = this.inventoryService.validateItemData({
            name, quantity, price, supplierName: supplier
        });

        if (!validation.isValid) {
            this.showMessage(validation.errors.join(', '), 'error');
            return;
        }

        // Check if item name already exists
        if (this.inventoryService.getItemByName(name)) {
            this.showMessage(`Item "${name}" already exists!`, 'error');
            return;
        }

        const newItem = new Item(name, category, quantity, price, supplier, popular, comment);
        
        if (this.inventoryService.addItem(newItem)) {
            this.showMessage(`Item "${name}" added successfully!`, 'success');
            this.clearAddForm();
            this.displayAllItems();
            this.updateNavStats();
        } else {
            this.showMessage('Failed to add item', 'error');
        }
    }

    private handleUpdateItem(e: Event): void {
        e.preventDefault();
        
        const searchNameInput = document.getElementById('update-search-name') as HTMLInputElement;
        const searchName = searchNameInput.value.trim();
        
        if (!searchName) {
            this.showMessage('Please enter an item name to search for update', 'error');
            return;
        }

        const existingItem = this.inventoryService.getItemByName(searchName);
        
        if (!existingItem) {
            this.showMessage(`Item "${searchName}" not found!`, 'error');
            return;
        }

        this.populateUpdateForm(existingItem);
        const updateSection = document.getElementById('update-fields-section');
        if (updateSection) updateSection.style.display = 'block';
    }

    private handleDeleteItem(): void {
        const nameInput = document.getElementById('delete-name') as HTMLInputElement;
        const name = nameInput.value.trim();
        
        if (!name) {
            this.showMessage('Please enter an item name to delete', 'error');
            return;
        }

        const item = this.inventoryService.getItemByName(name);
        
        if (!item) {
            this.showMessage(`Item "${name}" not found!`, 'error');
            return;
        }

        if (confirm(`Are you sure you want to delete "${name}"? This action cannot be undone.`)) {
            if (this.inventoryService.deleteItemByName(name)) {
                this.showMessage(`Item "${name}" deleted successfully!`, 'success');
                nameInput.value = '';
                this.displayAllItems();
                this.updateNavStats();
            } else {
                this.showMessage('Failed to delete item', 'error');
            }
        }
    }

    private handleSearch(): void {
        const searchInput = document.getElementById('search-input') as HTMLInputElement;
        const searchTerm = searchInput.value.trim();
        
        if (!searchTerm) {
            this.displayAllItems();
            return;
        }
        
        const results = this.inventoryService.searchItemsByName(searchTerm);
        this.displayItems(results, `Search Results for "${this.escapeHtml(searchTerm)}"`);
    }

    private displayAllItems(): void {
        const items = this.inventoryService.getAllItems();
        this.displayItems(items, 'All Inventory Items');
    }

    private displayPopularItems(): void {
        const items = this.inventoryService.getPopularItems();
        this.displayItems(items, 'Popular Items');
    }

    private displayItems(items: Item[], title: string): void {
        if (!this.currentDisplayElement) return;

        if (items.length === 0) {
            this.currentDisplayElement.innerHTML = `
                <div class="empty-state">
                    <div class="empty-state-icon">📦</div>
                    <p>No items to display</p>
                    <p style="font-size: 0.8rem; margin-top: 0.5rem;">Click "Add New Item" to get started</p>
                </div>
            `;
            return;
        }

        const tableHtml = `
            <table class="inventory-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Item Name</th>
                        <th>Category</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>Supplier</th>
                        <th>Stock Status</th>
                        <th>Popular</th>
                        <th>Comment</th>
                    </tr>
                </thead>
                <tbody>
                    ${items.map(item => `
                        <tr class="${item.stockStatus === 'Out of Stock' ? 'out-of-stock' : ''}">
                            <td>${item.id}</td>
                            <td><strong>${this.escapeHtml(item.name)}</strong></td>
                            <td>${this.getCategoryIcon(item.category)} ${item.category}</td>
                            <td>${item.quantity}</td>
                            <td>$${item.price.toFixed(2)}</td>
                            <td>${this.escapeHtml(item.supplierName)}</td>
                            <td><span class="status-badge status-${item.stockStatus.replace(/\s/g, '-')}">${item.stockStatus}</span></td>
                            <td>${item.popularItem === 'Yes' ? '<span class="popular-badge">⭐ Popular</span>' : 'No'}</td>
                            <td>${this.escapeHtml(item.comment || '-')}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
            <div style="padding: 1rem; text-align: right; border-top: 1px solid var(--gray-200);">
                <small style="color: var(--gray-500);">Showing ${items.length} item(s)</small>
            </div>
        `;
        
        this.currentDisplayElement.innerHTML = tableHtml;
    }

    private getCategoryIcon(category: string): string {
        const icons: Record<string, string> = {
            'Electronics': '📱',
            'Furniture': '🪑',
            'Clothing': '👕',
            'Tools': '🔧',
            'Miscellaneous': '📦'
        };
        return icons[category] || '📦';
    }

    private updateNavStats(): void {
        const items = this.inventoryService.getAllItems();
        const totalItems = items.length;
        const popularItems = items.filter(i => i.popularItem === 'Yes').length;
        const lowStockItems = items.filter(i => i.stockStatus === 'Low Stock').length;
        
        const totalEl = document.getElementById('total-items');
        const popularEl = document.getElementById('popular-items');
        const lowStockEl = document.getElementById('low-stock');
        
        if (totalEl) totalEl.textContent = totalItems.toString();
        if (popularEl) popularEl.textContent = popularItems.toString();
        if (lowStockEl) lowStockEl.textContent = lowStockItems.toString();
    }

    private showMessage(message: string, type: 'success' | 'error'): void {
        const messageDiv = document.getElementById('message-area');
        if (!messageDiv) return;
        
        const alertClass = type === 'success' ? 'success' : 'error';
        messageDiv.innerHTML = `<div class="message ${alertClass}">${type === 'success' ? '✓' : '✗'} ${this.escapeHtml(message)}</div>`;
        
        setTimeout(() => {
            if (messageDiv.firstChild) {
                messageDiv.removeChild(messageDiv.firstChild);
            }
        }, 3000);
    }

    private clearAddForm(): void {
        const inputs = ['add-name', 'add-quantity', 'add-price', 'add-supplier'];
        inputs.forEach(id => {
            const el = document.getElementById(id) as HTMLInputElement;
            if (el) el.value = '';
        });
        const categorySelect = document.getElementById('add-category') as HTMLSelectElement;
        if (categorySelect) categorySelect.value = 'Electronics';
        const popularSelect = document.getElementById('add-popular') as HTMLSelectElement;
        if (popularSelect) popularSelect.value = 'No';
        const commentArea = document.getElementById('add-comment') as HTMLTextAreaElement;
        if (commentArea) commentArea.value = '';
    }

    private clearUpdateForm(): void {
        const inputs = ['update-name', 'update-quantity', 'update-price', 'update-supplier'];
        inputs.forEach(id => {
            const el = document.getElementById(id) as HTMLInputElement;
            if (el) el.value = '';
        });
        const categorySelect = document.getElementById('update-category') as HTMLSelectElement;
        if (categorySelect) categorySelect.value = 'Electronics';
        const popularSelect = document.getElementById('update-popular') as HTMLSelectElement;
        if (popularSelect) popularSelect.value = 'No';
        const commentArea = document.getElementById('update-comment') as HTMLTextAreaElement;
        if (commentArea) commentArea.value = '';
    }

    private escapeHtml(str: string): string {
        if (!str) return '';
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }
}

// Initialize the app when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    new InventoryApp();
});