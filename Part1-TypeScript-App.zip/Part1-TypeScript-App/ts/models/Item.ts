// ts/models/Item.ts
// Author: [Your Name]
// Assignment: PROG2005 A2 Part 1
// Description: Inventory item data model

export type Category = 'Electronics' | 'Furniture' | 'Clothing' | 'Tools' | 'Miscellaneous';
export type StockStatus = 'In Stock' | 'Low Stock' | 'Out of Stock';
export type PopularStatus = 'Yes' | 'No';

export interface IItem {
    id: number;
    name: string;
    category: Category;
    quantity: number;
    price: number;
    supplierName: string;
    stockStatus: StockStatus;
    popularItem: PopularStatus;
    comment?: string;
}

export class Item implements IItem {
    private static nextId: number = 1;
    
    public id: number;
    public name: string;
    public category: Category;
    public quantity: number;
    public price: number;
    public supplierName: string;
    public stockStatus: StockStatus;
    public popularItem: PopularStatus;
    public comment?: string;

    constructor(
        name: string,
        category: Category,
        quantity: number,
        price: number,
        supplierName: string,
        popularItem: PopularStatus,
        comment?: string
    ) {
        this.id = Item.nextId++;
        this.name = name;
        this.category = category;
        this.quantity = quantity;
        this.price = price;
        this.supplierName = supplierName;
        this.stockStatus = this.calculateStockStatus(quantity);
        this.popularItem = popularItem;
        this.comment = comment;
    }

    private calculateStockStatus(quantity: number): StockStatus {
        if (quantity <= 0) return 'Out of Stock';
        if (quantity < 10) return 'Low Stock';
        return 'In Stock';
    }

    public updateStockStatus(): void {
        this.stockStatus = this.calculateStockStatus(this.quantity);
    }

    public updateQuantity(newQuantity: number): void {
        this.quantity = newQuantity;
        this.updateStockStatus();
    }
}