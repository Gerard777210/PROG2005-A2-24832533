# Inventory Management System - PROG2005 A2 Part 1

## 运行说明
Since the project uses ES Module, it needs to be run through an HTTP server:
###  Live Server 
```bash
npx live-server